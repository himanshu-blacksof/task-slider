import './App.css';
import Sidebar from './component/sidebar';
import Table from './component/table';

function App() {
  return (
    <>
      <Sidebar />
      {/* <Table /> */}
    </>
  );
}

export default App;
